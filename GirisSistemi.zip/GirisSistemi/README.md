MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR

GirisSistemi — kayıt / giriş eklentisi (Paper 26.2, Java 25)

Komutlar: /register, /login, /changepassword, /authadmin reset <oyuncu>
Gmail zorunlu, giriş ekranı kapanmaz, aynı IP'den gün boyu otomatik giriş (config.yml: oto-giris-saat, oto-giris-esik).
