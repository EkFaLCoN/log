package tr.mrwqlf.giris;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.event.player.AsyncChatEvent;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

public final class GirisSistemi extends JavaPlugin implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final Pattern GMAIL = Pattern.compile("^[a-z0-9._+-]{3,64}@gmail\\.com$");
    private static final Set<String> IZINLI_KOMUTLAR = Set.of("register", "reg", "login", "l");

    private final Set<UUID> girisYapanlar = new HashSet<>();
    private final Map<UUID, Integer> denemeler = new HashMap<>();
    private final Map<UUID, BukkitTask> zamanAsimlari = new HashMap<>();
    private final Map<UUID, String[]> oturumlar = new HashMap<>(); // uuid -> {ip, bitisMs}
    private final SecureRandom rastgele = new SecureRandom();

    private File veriDosyasi;
    private YamlConfiguration veri;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        veriDosyasi = new File(getDataFolder(), "veri.yml");
        veri = YamlConfiguration.loadConfiguration(veriDosyasi);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Giriş Sistemi etkinleştirildi.");
    }

    // ───────────────────────── Yardımcılar ─────────────────────────

    private Component msg(String mini) {
        return MM.deserialize(mini);
    }

    private boolean girisYapmis(Player p) {
        return girisYapanlar.contains(p.getUniqueId());
    }

    private boolean kayitli(UUID id) {
        return veri.isConfigurationSection("oyuncular." + id);
    }

    private void kaydet() {
        try {
            veri.save(veriDosyasi);
        } catch (IOException e) {
            getLogger().severe("Veri dosyası kaydedilemedi: " + e.getMessage());
        }
    }

    private String hashle(String sifre, byte[] tuz) {
        try {
            PBEKeySpec spec = new PBEKeySpec(sifre.toCharArray(), tuz, 65536, 256);
            byte[] h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(h);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void sifreyiKaydet(String yol, String sifre) {
        byte[] tuz = new byte[16];
        rastgele.nextBytes(tuz);
        veri.set(yol + ".tuz", Base64.getEncoder().encodeToString(tuz));
        veri.set(yol + ".hash", hashle(sifre, tuz));
    }

    private boolean sifreDogru(UUID id, String sifre) {
        String yol = "oyuncular." + id;
        String tuz = veri.getString(yol + ".tuz");
        String hash = veri.getString(yol + ".hash");
        if (tuz == null || hash == null) return false;
        String hesap = hashle(sifre, Base64.getDecoder().decode(tuz));
        return MessageDigest.isEqual(hesap.getBytes(), hash.getBytes());
    }

    private String gmailAnahtari(String gmail) {
        String[] parca = gmail.toLowerCase(Locale.ROOT).split("@", 2);
        String yerel = parca[0];
        int arti = yerel.indexOf('+');
        if (arti >= 0) yerel = yerel.substring(0, arti);
        return yerel.replace(".", "") + "@gmail.com";
    }

    private int gmailHesapSayisi(String gmail) {
        ConfigurationSection oyuncular = veri.getConfigurationSection("oyuncular");
        if (oyuncular == null) return 0;
        String anahtar = gmailAnahtari(gmail);
        int sayi = 0;
        for (String k : oyuncular.getKeys(false)) {
            String g = oyuncular.getString(k + ".gmail");
            if (g != null && gmailAnahtari(g).equals(anahtar)) sayi++;
        }
        return sayi;
    }

    private String ip(Player p) {
        return p.getAddress() != null ? p.getAddress().getAddress().getHostAddress() : "?";
    }

    // ───────────────────────── Giriş / çıkış ─────────────────────────

    private void girisBasarili(Player p) {
        UUID id = p.getUniqueId();
        girisYapanlar.add(id);
        denemeler.remove(id);
        BukkitTask t = zamanAsimlari.remove(id);
        if (t != null) t.cancel();
        p.closeDialog();
        p.sendMessage(msg("<green>✔ Başarıyla giriş yaptın. İyi oyunlar, <white>" + p.getName() + "<green>!"));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        girisYapanlar.remove(id);
        denemeler.remove(id);

        String[] oturum = oturumlar.remove(id);
        if (oturum != null && oturum[0].equals(ip(p)) && Long.parseLong(oturum[1]) > System.currentTimeMillis() && kayitli(id)) {
            girisYapanlar.add(id);
            p.sendMessage(msg("<green>✔ Oturumun hâlâ açık, otomatik giriş yapıldı."));
            return;
        }

        int saniye = getConfig().getInt("zaman-asimi-saniye", 90);
        zamanAsimlari.put(id, Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && !girisYapmis(p)) {
                p.kick(msg("<red>Giriş süresi doldu. Lütfen tekrar bağlan."));
            }
        }, saniye * 20L));

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline() || girisYapmis(p)) return;
            if (kayitli(id)) girisGoster(p, null); else kayitGoster(p, null);
        }, 10L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        BukkitTask t = zamanAsimlari.remove(id);
        if (t != null) t.cancel();
        int dk = getConfig().getInt("oturum-dakika", 0);
        if (girisYapanlar.remove(id) && dk > 0) {
            oturumlar.put(id, new String[]{ip(p), String.valueOf(System.currentTimeMillis() + dk * 60_000L)});
        }
        denemeler.remove(id);
    }

    // ───────────────────────── Diyaloglar ─────────────────────────

    private ActionButton cikisDugmesi(Player p) {
        return ActionButton.create(
                msg("<red>Sunucudan Çık"),
                msg("<gray>Sunucudan ayrıl"),
                150,
                DialogAction.customClick((view, audience) ->
                        Bukkit.getScheduler().runTask(this, () -> p.kick(msg("<yellow>Sunucudan ayrıldın."))),
                        ClickCallback.Options.builder().build()));
    }

    private void kayitGoster(Player p, String hata) {
        List<DialogBody> govde = new ArrayList<>();
        govde.add(DialogBody.plainMessage(msg("<gray>Sunucumuza ilk kez giriyorsun. Hesabını korumak için bir Gmail adresi ve şifre belirle.")));
        if (hata != null) govde.add(DialogBody.plainMessage(msg("<red>✖ " + hata)));

        int max = getConfig().getInt("max-sifre", 32);
        List<DialogInput> girdiler = List.of(
                DialogInput.text("gmail", msg("<white>Gmail adresin")).width(300).maxLength(64).build(),
                DialogInput.text("sifre", msg("<white>Şifreni belirle")).width(300).maxLength(max).build(),
                DialogInput.text("sifre2", msg("<white>Şifreni tekrar yaz")).width(300).maxLength(max).build());

        ActionButton kayit = ActionButton.create(
                msg("<green>Kayıt Ol"),
                msg("<gray>Hesabını oluştur"),
                150,
                DialogAction.customClick((DialogResponseView view, net.kyori.adventure.audience.Audience a) -> {
                    String g = view.getText("gmail");
                    String s = view.getText("sifre");
                    String s2 = view.getText("sifre2");
                    Bukkit.getScheduler().runTask(this, () -> kayitIsle(p, g, s, s2));
                }, ClickCallback.Options.builder().build()));

        Dialog dialog = Dialog.create(b -> b.empty()
                .base(DialogBase.builder(msg("<green><bold>Hoş Geldin!"))
                        .canCloseWithEscape(false)
                        .body(govde)
                        .inputs(girdiler)
                        .build())
                .type(DialogType.confirmation(kayit, cikisDugmesi(p))));
        p.showDialog(dialog);
    }

    private void girisGoster(Player p, String hata) {
        List<DialogBody> govde = new ArrayList<>();
        govde.add(DialogBody.plainMessage(msg("<gray>Tekrar hoş geldin! Devam etmek için şifreni gir.")));
        if (hata != null) govde.add(DialogBody.plainMessage(msg("<red>✖ " + hata)));

        int max = getConfig().getInt("max-sifre", 32);
        List<DialogInput> girdiler = List.of(
                DialogInput.text("sifre", msg("<white>Şifren")).width(300).maxLength(max).build());

        ActionButton giris = ActionButton.create(
                msg("<green>Giriş Yap"),
                msg("<gray>Hesabına giriş yap"),
                150,
                DialogAction.customClick((DialogResponseView view, net.kyori.adventure.audience.Audience a) -> {
                    String s = view.getText("sifre");
                    Bukkit.getScheduler().runTask(this, () -> girisIsle(p, s));
                }, ClickCallback.Options.builder().build()));

        Dialog dialog = Dialog.create(b -> b.empty()
                .base(DialogBase.builder(msg("<green><bold>Giriş Yap"))
                        .canCloseWithEscape(false)
                        .body(govde)
                        .inputs(girdiler)
                        .build())
                .type(DialogType.confirmation(giris, cikisDugmesi(p))));
        p.showDialog(dialog);
    }

    // ───────────────────────── İşlemler ─────────────────────────

    private String sifreHatasi(Player p, String s, String s2) {
        int min = getConfig().getInt("min-sifre", 6);
        int max = getConfig().getInt("max-sifre", 32);
        if (s == null || s.isEmpty()) return "Şifre boş olamaz.";
        if (s.length() < min) return "Şifre en az " + min + " karakter olmalı.";
        if (s.length() > max) return "Şifre en fazla " + max + " karakter olabilir.";
        if (s.equalsIgnoreCase(p.getName())) return "Şifren kullanıcı adınla aynı olamaz.";
        if (s2 != null && !s.equals(s2)) return "Şifreler birbiriyle uyuşmuyor.";
        return null;
    }

    private void kayitIsle(Player p, String gmail, String sifre, String sifre2) {
        if (!p.isOnline() || girisYapmis(p)) return;
        if (kayitli(p.getUniqueId())) {
            girisGoster(p, null);
            return;
        }
        gmail = gmail == null ? "" : gmail.trim().toLowerCase(Locale.ROOT);
        if (!GMAIL.matcher(gmail).matches()) {
            kayitGoster(p, "Geçerli bir Gmail adresi gir (örnek: isim@gmail.com).");
            return;
        }
        String hata = sifreHatasi(p, sifre, sifre2);
        if (hata != null) {
            kayitGoster(p, hata);
            return;
        }
        int limit = getConfig().getInt("gmail-basina-hesap", 2);
        if (gmailHesapSayisi(gmail) >= limit) {
            kayitGoster(p, "Bu Gmail adresiyle açılabilecek hesap sınırına ulaşıldı.");
            return;
        }
        String yol = "oyuncular." + p.getUniqueId();
        veri.set(yol + ".isim", p.getName());
        veri.set(yol + ".gmail", gmail);
        veri.set(yol + ".kayit-ip", ip(p));
        veri.set(yol + ".kayit-tarihi", System.currentTimeMillis());
        sifreyiKaydet(yol, sifre);
        kaydet();
        p.sendMessage(msg("<green>✔ Kayıt tamamlandı! Hesabın <white>" + gmail + "<green> adresiyle eşleştirildi."));
        girisBasarili(p);
    }

    private void girisIsle(Player p, String sifre) {
        if (!p.isOnline() || girisYapmis(p)) return;
        UUID id = p.getUniqueId();
        if (!kayitli(id)) {
            kayitGoster(p, null);
            return;
        }
        if (sifre != null && sifreDogru(id, sifre)) {
            veri.set("oyuncular." + id + ".isim", p.getName());
            veri.set("oyuncular." + id + ".son-ip", ip(p));
            kaydet();
            girisBasarili(p);
            return;
        }
        int max = getConfig().getInt("max-deneme", 3);
        int deneme = denemeler.merge(id, 1, Integer::sum);
        if (deneme >= max) {
            p.kick(msg("<red>Çok fazla hatalı şifre denemesi yaptın."));
            return;
        }
        girisGoster(p, "Şifre yanlış! Kalan deneme hakkı: " + (max - deneme));
    }

    // ───────────────────────── Komutlar ─────────────────────────

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String ad = cmd.getName().toLowerCase(Locale.ROOT);

        if (ad.equals("authadmin")) {
            if (args.length == 2 && args[0].equalsIgnoreCase("reset")) {
                ConfigurationSection oyuncular = veri.getConfigurationSection("oyuncular");
                String bulunan = null;
                if (oyuncular != null) {
                    for (String k : oyuncular.getKeys(false)) {
                        String isim = oyuncular.getString(k + ".isim");
                        if (isim != null && isim.equalsIgnoreCase(args[1])) {
                            bulunan = k;
                            break;
                        }
                    }
                }
                if (bulunan == null) {
                    sender.sendMessage(msg("<red>Bu isimde kayıtlı bir oyuncu bulunamadı."));
                    return true;
                }
                veri.set("oyuncular." + bulunan, null);
                kaydet();
                sender.sendMessage(msg("<green>✔ <white>" + args[1] + "<green> adlı oyuncunun kaydı sıfırlandı. Tekrar kayıt olması gerekecek."));
                Player hedef = Bukkit.getPlayerExact(args[1]);
                if (hedef != null) {
                    girisYapanlar.remove(hedef.getUniqueId());
                    hedef.kick(msg("<yellow>Hesabın sıfırlandı. Lütfen tekrar bağlanıp yeniden kayıt ol."));
                }
            } else {
                sender.sendMessage(msg("<yellow>Kullanım: /authadmin reset <oyuncu>"));
            }
            return true;
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage(msg("<red>Bu komutu sadece oyuncular kullanabilir."));
            return true;
        }
        UUID id = p.getUniqueId();

        switch (ad) {
            case "register" -> {
                if (kayitli(id)) {
                    p.sendMessage(msg("<red>Zaten kayıtlısın. Giriş yapmak için /login kullan."));
                } else if (args.length == 0) {
                    kayitGoster(p, null);
                } else if (args.length == 3) {
                    kayitIsle(p, args[0], args[1], args[2]);
                } else {
                    p.sendMessage(msg("<yellow>Kullanım: /register <gmail> <şifre> <şifre-tekrar>"));
                }
            }
            case "login" -> {
                if (girisYapmis(p)) {
                    p.sendMessage(msg("<red>Zaten giriş yaptın."));
                } else if (!kayitli(id)) {
                    p.sendMessage(msg("<red>Önce kayıt olmalısın: /register"));
                    kayitGoster(p, null);
                } else if (args.length == 0) {
                    girisGoster(p, null);
                } else if (args.length == 1) {
                    girisIsle(p, args[0]);
                } else {
                    p.sendMessage(msg("<yellow>Kullanım: /login <şifre>"));
                }
            }
            case "changepassword" -> {
                if (!girisYapmis(p)) {
                    p.sendMessage(msg("<red>Önce giriş yapmalısın."));
                } else if (args.length != 2) {
                    p.sendMessage(msg("<yellow>Kullanım: /changepassword <eski-şifre> <yeni-şifre>"));
                } else if (!sifreDogru(id, args[0])) {
                    p.sendMessage(msg("<red>Eski şifren yanlış."));
                } else {
                    String hata = sifreHatasi(p, args[1], null);
                    if (hata != null) {
                        p.sendMessage(msg("<red>" + hata));
                    } else {
                        sifreyiKaydet("oyuncular." + id, args[1]);
                        kaydet();
                        p.sendMessage(msg("<green>✔ Şifren başarıyla değiştirildi."));
                    }
                }
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    // ───────────────────────── Giriş yapmamış oyuncuyu kısıtla ─────────────────────────

    private boolean kilitli(Player p) {
        return !girisYapmis(p);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!kilitli(e.getPlayer())) return;
        Location a = e.getFrom();
        Location b = e.getTo();
        if (a.getX() != b.getX() || a.getY() != b.getY() || a.getZ() != b.getZ()) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (kilitli(e.getPlayer())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(msg("<red>Sohbet etmek için önce giriş yapmalısın."));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!kilitli(e.getPlayer())) return;
        String ilk = e.getMessage().substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        int iki = ilk.indexOf(':');
        if (iki >= 0) ilk = ilk.substring(iki + 1);
        if (!IZINLI_KOMUTLAR.contains(ilk)) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(msg("<red>Komut kullanmak için önce giriş yapmalısın."));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (kilitli(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (kilitli(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (kilitli(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (kilitli(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (kilitli(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (kilitli(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && kilitli(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInvClick(InventoryClickEvent e) {
        HumanEntity h = e.getWhoClicked();
        if (h instanceof Player p && kilitli(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInvOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p && kilitli(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && kilitli(p)) e.setCancelled(true);
    }
}
